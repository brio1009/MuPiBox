import{b as a,c as b}from"./chunk-N7R6TYCM.js";import"./chunk-RLXPGMKU.js";export{a as GESTURE_CONTROLLER,b as createGesture};
